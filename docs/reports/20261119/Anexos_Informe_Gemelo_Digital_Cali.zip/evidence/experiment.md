# Experimento de cooperación PPO

Estado: completed

## Modelos

| Alpha | Semilla | Modelo |
|---|---|---|
| 0.0 | 0 | models/ppo_roosevelt4_a0_s0_20261119-190642-303525 |
| 0.0 | 1 | models/ppo_roosevelt4_a0_s1_20261119-193808-746387 |
| 0.0 | 2 | models/ppo_roosevelt4_a0_s2_20261119-201823-002694 |
| 0.3 | 0 | models/ppo_roosevelt4_a0.3_s0_20261119-211423-590455 |
| 0.3 | 1 | models/ppo_roosevelt4_a0.3_s1_20261119-214910-022404 |
| 0.3 | 2 | models/ppo_roosevelt4_a0.3_s2_20261119-223441-232368 |

## Variación entre semillas de entrenamiento

Score: espera normalizada por fijo, media de tres escenarios; menor es mejor.
Media y desviación entre modelos, distintas de la variación de demanda.

| Alpha | Modelos | Score medio | Desviación | Elegibles |
|---|---|---|---|---|
| 0.0 | 3 | 0.3342 | 0.0028 | 3 |
| 0.3 | 3 | 0.3323 | 0.0007 | 3 |

Validación: `outputs/evaluations/cooperation_20261119/validation`.

## Selección fijada antes de la prueba final

Minimize the equal-weight mean of validation waiting/fixed waiting over peak, valley and event. Require paired peak waiting reduction >=15%, no more teleports than fixed, and at least 99% of fixed completed trips in each scenario. Ties: strategy name. Fairness is reported separately. Never rerank using final-test results.

Modelo: `models/ppo_roosevelt4_a0_s2_20261119-201823-002694`.


Prueba final del único modelo fijado: `outputs/evaluations/cooperation_20261119/test`.
Los resultados finales no se usan para elegir otro candidato.

El modelo del panel no se cambia automáticamente.
Demanda sintética; no es una validación con aforos de campo.
