# Objetivo: ≥ 15% menos espera media que tiempo fijo (peak)

Reducción por semilla = (fijo − estrategia) / fijo, sobre la espera media por viaje (`waitingTime` de tripinfo, incluye vehículos sin terminar). IC 95 % por bootstrap sobre semillas.

| Estrategia | Semillas | Reducción media | IC 95 % | Resultado |
|---|---|---|---|---|
| maxpressure | 5 | +57.9% | [+52.0%, +63.8%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s0_20261119-211423-590455 | 5 | +70.1% | [+67.4%, +72.7%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s1_20261119-214910-022404 | 5 | +70.8% | [+68.5%, +73.6%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s2_20261119-223441-232368 | 5 | +69.5% | [+67.9%, +71.7%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s0_20261119-190642-303525 | 5 | +68.9% | [+67.0%, +71.6%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s1_20261119-193808-746387 | 5 | +69.1% | [+66.8%, +72.1%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s2_20261119-201823-002694 | 5 | +69.9% | [+68.1%, +71.7%] | CUMPLE |

# Objetivo: ≥ 15% menos espera media que tiempo fijo (valley)

Reducción por semilla = (fijo − estrategia) / fijo, sobre la espera media por viaje (`waitingTime` de tripinfo, incluye vehículos sin terminar). IC 95 % por bootstrap sobre semillas.

| Estrategia | Semillas | Reducción media | IC 95 % | Resultado |
|---|---|---|---|---|
| maxpressure | 5 | +58.2% | [+53.5%, +62.0%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s0_20261119-211423-590455 | 5 | +60.4% | [+58.2%, +62.7%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s1_20261119-214910-022404 | 5 | +59.1% | [+56.6%, +61.6%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s2_20261119-223441-232368 | 5 | +60.1% | [+58.3%, +61.7%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s0_20261119-190642-303525 | 5 | +60.3% | [+57.9%, +63.7%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s1_20261119-193808-746387 | 5 | +60.8% | [+58.9%, +63.5%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s2_20261119-201823-002694 | 5 | +61.0% | [+59.4%, +63.3%] | CUMPLE |

# Objetivo: ≥ 15% menos espera media que tiempo fijo (event)

Reducción por semilla = (fijo − estrategia) / fijo, sobre la espera media por viaje (`waitingTime` de tripinfo, incluye vehículos sin terminar). IC 95 % por bootstrap sobre semillas.

| Estrategia | Semillas | Reducción media | IC 95 % | Resultado |
|---|---|---|---|---|
| maxpressure | 5 | +56.8% | [+53.3%, +61.2%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s0_20261119-211423-590455 | 5 | +69.0% | [+66.3%, +71.0%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s1_20261119-214910-022404 | 5 | +70.1% | [+67.0%, +72.5%] | CUMPLE |
| rl:ppo_roosevelt4_a0.3_s2_20261119-223441-232368 | 5 | +70.1% | [+67.8%, +72.0%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s0_20261119-190642-303525 | 5 | +69.2% | [+67.3%, +71.3%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s1_20261119-193808-746387 | 5 | +68.8% | [+66.0%, +71.1%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s2_20261119-201823-002694 | 5 | +69.4% | [+66.9%, +71.0%] | CUMPLE |
