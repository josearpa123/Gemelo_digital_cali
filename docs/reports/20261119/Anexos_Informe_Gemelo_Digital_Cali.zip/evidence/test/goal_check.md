# Objetivo: ≥ 15% menos espera media que tiempo fijo (peak)

Reducción por semilla = (fijo − estrategia) / fijo, sobre la espera media por viaje (`waitingTime` de tripinfo, incluye vehículos sin terminar). IC 95 % por bootstrap sobre semillas.

| Estrategia | Semillas | Reducción media | IC 95 % | Resultado |
|---|---|---|---|---|
| maxpressure | 5 | +58.4% | [+53.2%, +62.8%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s2_20261119-201823-002694 | 5 | +66.5% | [+62.3%, +69.2%] | CUMPLE |

# Objetivo: ≥ 15% menos espera media que tiempo fijo (valley)

Reducción por semilla = (fijo − estrategia) / fijo, sobre la espera media por viaje (`waitingTime` de tripinfo, incluye vehículos sin terminar). IC 95 % por bootstrap sobre semillas.

| Estrategia | Semillas | Reducción media | IC 95 % | Resultado |
|---|---|---|---|---|
| maxpressure | 5 | +62.0% | [+58.5%, +64.1%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s2_20261119-201823-002694 | 5 | +62.1% | [+58.5%, +65.1%] | CUMPLE |

# Objetivo: ≥ 15% menos espera media que tiempo fijo (event)

Reducción por semilla = (fijo − estrategia) / fijo, sobre la espera media por viaje (`waitingTime` de tripinfo, incluye vehículos sin terminar). IC 95 % por bootstrap sobre semillas.

| Estrategia | Semillas | Reducción media | IC 95 % | Resultado |
|---|---|---|---|---|
| maxpressure | 5 | +56.1% | [+53.4%, +59.0%] | CUMPLE |
| rl:ppo_roosevelt4_a0_s2_20261119-201823-002694 | 5 | +67.4% | [+63.1%, +69.9%] | CUMPLE |
